/**
 * Created with JetBrains WebStorm.
 * User: wilson
 * Date: 14-4-15
 * Time: 上午10:38
 * To change this template use File | Settings | File Templates.
 */

function Goods(goods){
   this.id = goods.id;
   this.name = goods.name;
   this.description = goods.description;
   this.img = goods.img;
   this.img1 = goods.img1;
}

var allGoods = [
    {id:1,name:'冰凉滋润',
    description:'本品采用天然草本秘方与天然薄荷为原料，有效滋润咽喉、亮嗓清嗓，且润肺生津、清热降火。每天一瓶，润喉润声，让您时刻“中国好声音”！',
    img:'IMG_2831.JPG',img1:'IMG_2831a.JPG'},
    {id:2,name:'红枣枸杞汁',
    description:'中国古语有云 :一日三枣-容颜不老,本产品含约24克红枣 ,枣味浓郁 , 口感香醇 ,本品系天然美肤的养生佳品 有助于气血调和。滋补、养颜。',
        img:'IMG_2832.JPG',img1:'IMG_2832a.JPG'},
    {id:3,name:'花旗参原味',
    description:'颜之堂花旗参原味饮料口感甘甜清爽，是一种补而不燥的高级佳品，产品富含40多种人参皂甙、17中氨基酸，包括精氨酸、萘胺酸等8中人体必需的氨基酸，能有效的提高体力和脑力，具有抗疲劳的作用，常饮精力充沛！',
        img:'IMG_2833.JPG',img1:'IMG_2833a.JPG'},
    {id:4,name:'珍珠蜜',
    description:'颜之堂珍珠蜜原味饮料口感甘甜清爽，增强人体抵抗力，产品富含15种氨基酸、30多种微量元素、富含的B族维生素和生物钙质，很好的解决了以往珍珠中的有效成分难以被人体吸收的难题，完整保留珍珠的天然成分。让您轻松保持美丽、娇嫩的肌肤！',
        img:'IMG_2834.JPG',img1:'IMG_2834a.JPG'},
    {id:5,name:'塑身一宝',
    description:'本品富含陈香佛手（台湾一宝“老香黄”）萃取精华、易吸收，有清淡柠檬香味、略咸。常饮有助于改善体内环境，美体塑身。',
        img:'IMG_2835.JPG',img1:'IMG_2835a.JPG'},
    {id:6,name:'灵芝原味',
    description:'颜之堂灵芝原味饮料口感甘甜清爽是一种补而不燥的高级佳品。产品富含灵芝多糖、多肽类及12种氨基酸，包括精氨酸等人体必需的氨基酸，常饮养颜护肤增强人体体质经常饮用能达到调节身体机能。',
        img:'IMG_2836.JPG',img1:'IMG_2836a.JPG'}
    ];

module.exports = Goods;

Goods.getAll = function(callback){
    callback(allGoods);
};

Goods.get = function(gid,callback){
    var myGoods;
    var goods;

    for(var i=0; i<allGoods.length; i++){
        goods = new Goods(allGoods[i]);
        if(goods && goods.id === parseInt(gid)){
            myGoods = goods;
            break;
        }
    }
    if(myGoods){
        callback(null,myGoods);
    }else{
        callback('此商品不存在',null);
    }
};
