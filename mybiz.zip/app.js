
/**
 * Module dependencies.
 */

var express = require('express');
var routes = require('./routes');
var about = require('./routes/about');
var cont = require('./routes/contact');
var goods = require('./routes/goods');
var user = require('./routes/user');
var http = require('http');
var path = require('path');
var ejs = require('ejs');
var fs = require('fs');
var accessLogfile = fs.createWriteStream('access.log', {flags: 'a'});
var errorLogfile = fs.createWriteStream('error.log', {flags: 'a'});

var app = express();
//var app = module.exports = express.createServer();
// all environments
app.set('port', process.env.PORT || 3000);
//app.set('views', path.join(__dirname, 'views'));
//app.set('view engine', 'ejs');
app.engine('.html', ejs.__express);
app.set('view engine', 'html');
app.use(express.logger({stream: accessLogfile}));
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.json());
app.use(express.urlencoded());
app.use(express.methodOverride());
app.use(express.cookieParser());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));

app.configure('development', function(){
    app.use(express.errorHandler({ dumpExceptions: true, showStack: true }));
});

app.configure('production', function(){
    app.error(function(err, req, res, next) {
        varmeta = '[' + new Date() + '] ' + req.url + '\n';
        errorLogfile.write(meta + err.stack + '\n');
        next();
    });
});

// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}

app.get('/', routes.index);
app.get('/index', routes.index);
app.get('/goods', goods.goods);
app.get('/about', about.about);
app.get('/contact', cont.contact);
app.get('/show/:gid', goods.show);
app.get('/users', user.list);


var myserver = http.createServer(app);
module.exports = myserver;
if(!module.parent){
    myserver.listen(app.get('port'), function(){
        console.log('Express server listening on port ' + app.get('port'));
    });
}
//http.createServer(app).listen(app.get('port'), function(){
//  console.log('Express server listening on port ' + app.get('port'));
//});
