
/*
 * GET home page.
 */

exports.contact = function(req, res){
  res.render('contact', { title: 'Express' });
};