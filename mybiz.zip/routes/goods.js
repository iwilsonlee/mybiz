
/*
 * GET goods page.
 */

var Goods = require('../models/goods');

exports.goods = function(req, res){
    Goods.getAll(function(allGoods){
        res.render('goods', { allGoods: allGoods });
    });

};

exports.show = function(req, res){
    var gid = req.params.gid;
    Goods.get(gid,function(err,goods){
        if(err){
            res.send(err);
        }else{
            res.render('show', { goods: goods });
        }

    });
};